Hello, and welcome to Alien: Containment!
This is a pure C# game that I built during my first month in Centriq Training's Full Stack Web Developer program.
Although it is a short experience, this game is designed to be unique each time you play it. With randomized enemies,
you never know what type of enemy you'll meet or where you'll meet them!
Your goal is to make it to the cargo bay in order to escape in the last available escape pod. There is a map provided for
your convenience to navigate through this open-world experience.
Keep an eye out for any equippables, and a closer eye out for any enemies that may be lurking about!
Once you reach the end, you will have to face the Xenomorph before you can escape. But be careful -- depending on your
game, you may end up facing a queen!

This project was so fun to build, and it really helped to cement the concepts that we were going over in class into my mind
and force me to think outside of the box in order to acheive the desired goals I had set for myself.

So, to that point, please enjoy Alien: Containment!