Hello, and welcome to my Intergalactic Space ATM!
This is a project that I made in my first month going through the Full Stack Web Developer track at Centriq. All of the functionality
was built during that first month except for the overdraw prevention, which I added a few weeks later while I was refactoring.
This was a challenging but fun project for a beginner, and it really helped to solidify all of the concepts that I had learned up to that point.
Features include: you must provide the correct account number AND PIN in order to log in. System will loop until you enter the correct credentials.
You may check your balance, make a deposit, and make a withdrawal. You may only make a withdrawl as your balance allows, though (no overdrawing).
So, without further ado, thank you for taking the time to check out my ATM application and enjoy!

The account number for the ATM is 00000, and the PIN is 1234
The account number and PIN are located at the top of ATM.cs in case you forget.